const Task1 = document.createElement("button");
const Task1Child = document.createTextNode("Task1");
Task1.appendChild(Task1Child);
Task1.addEventListener("click",ClickTask1);
const Task2 = document.createElement("button");
const Task2Child = document.createTextNode("Task2");
Task2.appendChild(Task2Child);
Task2.addEventListener("click",ClickTask2);
const Task3 = document.createElement("button");
const Task3Child = document.createTextNode("Task3");
Task3.appendChild(Task3Child);
Task3.addEventListener("click",ClickTask3);

let CommentList = [];


function ShowAndHide(){
    

    const eleSection = document.getElementById("hidesec");

    if (document.getElementById("Show").innerHTML=="Show"){
        document.getElementById("Show").innerHTML="Hide";
        eleSection.appendChild(Task1);
        eleSection.appendChild(Task2);
        eleSection.appendChild(Task3);
    }
    else {
        document.getElementById("Show").innerHTML="Show";
        eleSection.removeChild(eleSection.firstElementChild);
        eleSection.removeChild(eleSection.firstElementChild);
        eleSection.removeChild(eleSection.firstElementChild);
    }
    console.log("clicked show/hide");
    
    

}

function ClickTask1(){
    
    switch(document.getElementById("columns").className){
        case "container text-start":
            document.getElementById("columns").className = "container text-center";
            break;
        case "container text-end":
            document.getElementById("columns").className = "container text-start";
            break;
        case "container text-center":
            document.getElementById("columns").className = "container text-end";
            break;

        default:
            console.log("task 1 switch error");
    }
    console.log("clicked task 1");
}

function ClickTask2(){
    let NewPersonName = prompt("enter a spotlight of the celebrity");
    if (NewPersonName != null){
        const NewPersonEle = document.createElement("p");
        const NewPersonChild = document.createTextNode(NewPersonName);
        NewPersonEle.appendChild(NewPersonChild);
        document.getElementById("spotlight").appendChild(NewPersonEle);
    }
    console.log("clicked task 2");
}





function ClickTask3(){
    let readPercent = 0;
    
    readPercent = scrollY  / (document.body.clientHeight - window.innerHeight) *100;
    const progressBar = document.createElement("div");
    progressBar.className = "progress sticky-top";
    progressBar.setAttribute("id", "scrollBarBase")
    const progressBarContent = document.createElement("div");
    progressBarContent.classList.add("progress-bar");
    
    progressBarContent.role = "progressbar";
    progressBarContent.setAttribute("aria-label", "Basic example");
    progressBarContent.setAttribute("aria-valuenow", 20);
    progressBarContent.setAttribute("aria-valuemin", 0);
    progressBarContent.setAttribute("aria-valuemax", 100);
    progressBarContent.setAttribute("id", "scrollBar");
    progressBarContent.setAttribute("style", "width : " + readPercent + '%');

    window.onscroll = () => {scrolling()};
    progressBar.appendChild(progressBarContent);

   
    if (document.getElementById("scrollBarBase")== null){
        document.getElementById("body").insertBefore(progressBar,document.getElementById("mainsec"));
    }
    else {
        document.getElementById("scrollBarBase").remove();
    }
    console.log("clicked task 3");
}

function scrolling(){
    let readPercent = 0;
    if (document.getElementById("scrollBarBase")!= null){
        readPercent = scrollY  / (document.body.clientHeight - window.innerHeight) *100;
        document.getElementById("scrollBar").setAttribute("aria-valuenow", readPercent);
        document.getElementById("scrollBar").setAttribute("style", "width : " + readPercent + '%');
        console.log(scrollY + "/" + document.body.clientHeight);
    }
}


function processform() {
    
    let inputCheck = document.getElementById("new-email");
    let newCommentObject = new Object();

    if(!inputCheck.validity.valid){
        console.log("invaild email");
        return 0;        
    }

    newCommentObject.Email=document.querySelector("#new-email").value;


    inputCheck = document.getElementById("new-comment");

    if(!inputCheck.validity.valid){
        console.log("invaild comment");
        return 0;        
    }
    
    newCommentObject.Comment=document.querySelector("#new-comment").value;

    // set up a new element
    let newComment = document.createElement("div");
    let element = '<div><svg height="100" width="100"><circle cx="50" cy="50" r="40"></svg></div><div><h5></h5><p></p></div>';
    newComment.innerHTML = element;

    // set the classes of the div and its children div's
    newComment.className = "d-flex";
    newComment.querySelectorAll("div")[0].className = "flex-shrink-0"; // 1st div
    newComment.querySelectorAll("div")[1].className = "flex-grow-1"; // 2nd div

    // increment the comment id
    if(document.querySelector("#comments").lastElementChild != null){
        let lastComment = document.querySelector("#comments").lastElementChild; // #comments refer to the id "comments"
        newComment.id = 'c' + (Number(lastComment.id.substr(1))+1);
    }
    else{
        newComment.id = "c1001"
    }
    

    // change contents <h5> and <p> according to form input with id
    newComment.querySelector("h5").innerHTML = document.querySelector("#new-email").value;
    newComment.querySelector("p").innerHTML = document.querySelector("#new-comment").value;

    // get the color choice from the radio buttons
    let color = document.querySelectorAll("input[name=new-color]:checked")[0].value;

    newCommentObject.Color=color;

    CommentList.push(newCommentObject);
    console.log(CommentList);
    savefile();

    // change the fill color of the SVG circle
    newComment.querySelector("circle").setAttribute("fill", color);

    // append it to the div #comments
    document.querySelector("#comments").appendChild(newComment);

    // reset the form to clear the contents
    document.querySelector("form").reset();
}

function loadfile(){
     
    let receivedJson = new Object();

    
    fetch("asmt1_file.json")
      .then(response => response.text())
      .then(data => {
        
        receivedJson = JSON.parse(data);
        CommentList = receivedJson;
        console.log(receivedJson);

        
        for(let i in receivedJson){
            // set up a new element
            let newComment = document.createElement("div");
            let element = '<div><svg height="100" width="100"><circle cx="50" cy="50" r="40"></svg></div><div><h5></h5><p></p></div>';
            newComment.innerHTML = element;

            // set the classes of the div and its children div's
            newComment.className = "d-flex";
            newComment.querySelectorAll("div")[0].className = "flex-shrink-0"; // 1st div
            newComment.querySelectorAll("div")[1].className = "flex-grow-1"; // 2nd div

            // let lastComment = receivedJson[i].Comment; 
            newComment.id = 'c' + (1000 + i);
            let tempCommentObject = receivedJson[i];
            console.log(tempCommentObject);
            newComment.querySelector("h5").innerHTML = tempCommentObject.Email;
            newComment.querySelector("p").innerHTML = tempCommentObject.Comment;
            // get the color choice from the radio buttons
            let color = tempCommentObject.Color;

            // change the fill color of the SVG circle
            newComment.querySelector("circle").setAttribute("fill", color);

            // append it to the div #comments
            document.querySelector("#comments").appendChild(newComment);
        }


      })
      .catch(error => {
        console.error("Error fetching data:", error);
      });

    //   console.log(receivedJson);



}


function savefile(){
    

    let sendJson = JSON.stringify(CommentList);

    
    fetch("http://127.0.0.1:8080/asmt1_file.json", {
        method:"PUT",
        body: sendJson
    });
}