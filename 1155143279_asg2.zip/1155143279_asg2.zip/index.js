// SID:1155143279 Name:Lee Chi To,Eric

// I declare that the lab work here submitted is original
// except for source material explicitly acknowledged,
// and that the same or closely related material has not been
// previously submitted for another course.
// I also acknowledge that I am aware of University policy and
// regulations on honesty in academic work, and of the disciplinary
// guidelines and procedures applicable to breaches of such
// policy and regulations, as contained in the website.
// University Guideline on Academic Honesty:
// https://www.cuhk.edu.hk/policy/academichonesty/
// Student Name : Lee Chi To,Eric
// Student ID : 1155143279
// Class/Section : CSCI2720
// Date : 02/11/2023

import ReactDOM from "react-dom/client";
import React from 'react';
import {
  BrowserRouter,
  Routes,
  Route,
  Link,
} from 'react-router-dom';
import { useState , useEffect} from "react";

const data = [
  {filename: "cuhk-2013.jpg", year:2013, remarks: "Sunset over CUHK"}, 
  {filename: "cuhk-2017.jpg", year:2017, remarks: "Bird's-eye view of CUHK"},
  {filename: "sci-2013.jpg", year:2013, remarks: "The CUHK Emblem"}, 
  {filename: "shb-2013.jpg", year:2013, remarks: "The Engineering Buildings"},
  {filename: "stream-2009.jpg", year:2009, remarks: "Nature hidden in the campus"},
  ];


class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        <div>
          <ul>
            <li> <Link to="/">Home</Link> </li>
            <li> <Link to="/Gallery">Gallery</Link> </li>
            <li> <Link to="/Slideshow">Slideshow</Link> </li>
          </ul>
        </div>

        <hr />
        <Title name={this.props.name}/>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/Gallery" element={<Gallery />} />
          <Route path="/Slideshow" element={<Slideshow />} />
          <Route path="*" element={<NoMatch />} />
          
        </Routes>
        
        
      </BrowserRouter>
    );
  }
}

class Home extends React.Component {
  render() {
    return (
    <>
      <h2>Home</h2>;
      <div className="card d-inline-block m-2" >
          <img src={"TreeDiagramasmt2.png"} className="w-100" alt="Tree"/>
          <div className="card-body">
              <h6 className="card-title">TreeDiagram</h6>
          </div>
      </div>
    </>
    )
  }
}



function Slideshow() {
  
  const [photoID, setphotoID] = useState(0);
  const [TimeInterval, setTimeInterval] = useState(1500);
  const [isShuffle, setisShuffle] = useState(false);
  const [isStart, setisStart] = useState(false);


  useEffect(() => {
    if (isStart){
      const newInterval = setInterval(() => {nextSlide()}, TimeInterval);
      return () => {
        clearInterval(newInterval);
      };
    }
    
  }, [isStart,isShuffle,TimeInterval]);

  function nextSlide(){

    if (isShuffle === false){

      setphotoID((photoID)=>{return((photoID+1)%5)});

    }
    else {
      setphotoID(Math.floor(Math.random()*5));
    }
    
    
  }


  const handleStart = () => {
    setisStart(true);
  }

  const handleStop = () => {
    setisStart(false);
  }

  const handleSlow = () => {
    setTimeInterval(()=>{return(TimeInterval+200)})
  }

  const handleFast = () => {
    setTimeInterval(()=>{return(TimeInterval>200?(TimeInterval-200):TimeInterval)})
  }

  const handleShuffle = () => {
    setisShuffle(!isShuffle);
  }

  return (
    <>
    <h2>Slideshow</h2>
    <div className="card d-inline-block m-2" style={{width:400}} >
        <img src={"images/"+data[photoID].filename} className="w-100" alt="cuhk"/>
        <div className="card-body">
            <h6 className="card-title">{data[photoID].filename}</h6>
            <p className="card-text">{data[photoID].year}</p>
        </div>
    </div>
    <br></br>
    <button onClick={()=>handleStart()}>Start</button>
    <button onClick={()=>handleStop()}>Stop</button>
    <button onClick={()=>handleSlow()}>Slower</button>
    <button onClick={()=>handleFast()}>Faster</button>
    <button onClick={()=>handleShuffle()}>Shuffle</button>
    </>
  );
  
  
}

class Title extends React.Component {
  render() {
      return (
          <header className="bg-warning">
              <h1 className="display-4 text-center">{this.props.name}</h1>
          </header>
      );
  }
}

class Gallery extends React.Component {
  render() {
      return (
          <main className="container">
              {data.map((file,index) => <FileCard i={index} key={index}/>)}
          </main>
      );
  }
}

class FileCard extends React.Component {
    
  constructor(props) {
      super(props);
      this.state = { selected: -1 };
      }
  
  handleClick(index, e) {
      if (this.state.selected !== index) {
          this.setState({ selected: index });
        } else {
          this.setState({ selected: -1 });
        }
  }

  render() {
      let i = this.props.i;
      return (
              <div className="card d-inline-block m-2" style={{width:this.state.selected===i ? 400 : 200}} onMouseEnter={(e) => this.handleClick(i, e) } onMouseLeave={(e) => this.handleClick(i, e)}>
                  <img src={"images/"+data[i].filename} className="w-100" alt="cuhk"/>
                  <div className="card-body">
                      <h6 className="card-title">{data[i].filename}</h6>
                      <p className="card-text">{data[i].year}</p>
                  </div>
              </div>
      );
  }
}

class NoMatch extends React.Component {
  render() {
    return <h2>NoMatch</h2>;
  }
}


const root = ReactDOM.createRoot(document.querySelector('#app'));
root.render(<App name="CUHK pictures"/>);
