// SID:1155143279 Name:Lee Chi To,Eric

// I declare that the lab work here submitted is original
// except for source material explicitly acknowledged,
// and that the same or closely related material has not been
// previously submitted for another course.
// I also acknowledge that I am aware of University policy and
// regulations on honesty in academic work, and of the disciplinary
// guidelines and procedures applicable to breaches of such
// policy and regulations, as contained in the website.
// University Guideline on Academic Honesty:
// https://www.cuhk.edu.hk/policy/academichonesty/
// Student Name : Lee Chi To,Eric
// Student ID : 1155143279
// Class/Section : CSCI2720
// Date : 10/12/2023
const express = require('express');
const app = express();

const cors = require('cors');
app.use(cors());
app.use(express.json());

const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1:27017/myDatabase'); // put your own database link here

const db = mongoose.connection;
// Upon connection failure
db.on('error', console.error.bind(console, 'Connection error:'));
// Upon opening the database successfully
db.once('open', function () {
  console.log("Connection is open...");

  // creating a mongoose model
  const EventSchema = mongoose.Schema({
    eventID: {
      type: Number,
      required: [true, "eventID is required"]
    },
    name:{
      type: String,
      required: [true, "Name is required"]
    },
    _location: {
      type: mongoose.Schema.Types.ObjectId,
      ref:'Location',
      required: true,
    },
    quota: {
      type: Number,
      validate: {
        validator: function (value) {
          return value > 0;
        },
        message: () => "Please enter a valid quota",
      },
    },
  });

  const LocationSchema = mongoose.Schema({
    locID: {
      type: Number,
      required: [true, "eventID is required"]
    },
    name: {
      type: String,
      required:true
    },
    quota: {
      type: Number,
      validate: {
        validator: function (value) {
          return value > 0;
        },
        message: () => "Please enter a valid quota",
      },
    },
  })
  
  const Event = mongoose.model("Event", EventSchema);
  const Location = mongoose.model("Location", LocationSchema);  
  
  //P2
  app.get('/ev/:eventID',(req,res)=>{
    let ID = req.params.eventID;
    let DataFound;
    
    console.log("ID="+ID);
    DataFound = Event.findOne({ eventID: { $eq: ID } })
      .then((data) => {
        if (data==null) 
          throw 404;

        Location.findById(data._location)
        .then((locdata) => {
          res.set('Content-Type', 'text/plain');
          res.send("{\n\"eventID\": "+ data.eventID + ",\n" +
          "\"name\": \"" + data.name + "\",\n" +
          "\"loc\":" + "\n" +
          "{" + "\n" +
          "\"locId\": " + locdata.locID + ",\n" +
          "\"name\": \"" + locdata.name + "\"\n" +
          "}," + "\n" +
          "\"quota\": " + data.quota + "\n" +
          "}" + "\n"
          );
        })
      })
      .catch((error) => {
        console.log(error)

        res.set('Content-Type', 'text/plain');
        res.status(404).send("Event Not Found!")
      });
    
      
  });
  //P3
  app.post('/ev',(req,res)=>{
    let newname = req.body.name;
    let newquota = req.body.quota
    let reqlocID = req.body.locID;
    console.log("POST detected");
    res.set('Content-Type', 'text/plain');

    //Creating a new event
    Event.find({}).sort({eventID: 'desc'})
        .then((sortedList)=>{
          console.log("Largest="+ sortedList[0].eventID);
          sortedList[0].eventID
          let newID = sortedList[0].eventID + 1;

          Location.findOne({locID:{ $eq: reqlocID }})
            .then((locdata)=>{
              if(locdata.quota<newquota){
                throw 406;
              };

              let newEvent = new Event({
                eventID: newID,
                name:newname,
                _location: locdata._id,
                quota: newquota,
              });  
              //Saving this new event to database
              newEvent.save()
                .then(() => {
                  console.log("a new event created successfully");
                })
                .catch((error) => {
                  console.log("failed to save new event");
                });
                
              
              res.status(201).send("Event added sucessfully!")

            })
            .catch((error)=>{
              console.log(error);
              if (error==406) res.status(error).send("Error " + error + ":\nQuota is too many!")
            })
          
        })
        .catch((error)=>{
          console.log(error);
        })
    
  });
  //P4
  app.delete("/ev/:eventID",(req,res)=>{
    
    console.log("DELETE detected");    
    res.set('Content-Type', 'text/plain');    
    const newEventID = req.params.eventID;
    console.log("newEventID="+newEventID);
    // delete the event if event is found
    Event.findOneAndDelete(
      { eventID: { $eq : newEventID } }  
    )
    .then((data) => {
      if(data==null) throw 404;
      let message = 'the deleted data is:'+ data
      console.log(message);
      res.sendStatus(204);
    })
    .catch((error) => {
      console.log(error)
      res.status(404).send('Error:'+ error);
    });
  });
  //P5.Q5
  app.get('/ev?',(req,res)=>{
    console.log("/ev?q=number detected");   
    res.set('Content-Type', 'text/plain');
    let reqQuota = req.query.q;
    let message = "Q>"+ reqQuota +" Event Found!\n[\n";
    
    Event.find({quota : {$gt : reqQuota}})
      .then((data) => {
        if (data.length==0) {throw 404;}
        console.log(data.length==0);
        sendingmessage = (message) =>  {
          async function messagelooping(newmessage){
              for(let curEvent of data){
                await Location.findById(curEvent._location)
                .then((locdata) => {
                  newmessage+="{\n\"eventID\": "+ curEvent.eventID + ",\n" +
                  "\"name\": \"" + curEvent.name + "\",\n" +
                  "\"loc\":" + "\n" +
                  "{" + "\n" +
                  "\"locId\": " + locdata.locID + ",\n" +
                  "\"name\": \"" + locdata.name + "\"\n" +
                  "}," + "\n" +
                  "\"quota\": " + curEvent.quota + "\n" +
                  "}\n,\n";
                })
              }
              return newmessage;
          }
          messagelooping(message).then(
            (value)=>{
              message=value.slice(0,-2);
              res.send(message);
            }
          );
        }
        sendingmessage(message);
      })
      .catch((error) => {
        console.log(error)
        res.set('Content-Type', 'text/plain');
        res.send([])
      })    
      ;
  });
  //P5.Q1
  app.get('/ev',(req,res)=>{
    console.log("/ev detected");   
    res.set('Content-Type', 'text/plain');
    let message = "All Event Found!\n[\n";
    
    Event.find({})
      .then((data) => {
        if (data==null) {throw 404;}
        sendingmessage = (message) =>  {

          async function messagelooping(newmessage){
              for(let curEvent of data){
                await Location.findById(curEvent._location)
                .then((locdata) => {              
                  newmessage+="{\n\"eventID\": "+ curEvent.eventID + ",\n" +
                  "\"name\": \"" + curEvent.name + "\",\n" +
                  "\"loc\":" + "\n" +
                  "{" + "\n" +
                  "\"locId\": " + locdata.locID + ",\n" +
                  "\"name\": \"" + locdata.name + "\"\n" +
                  "}," + "\n" +
                  "\"quota\": " + curEvent.quota + "\n" +
                  "}\n,\n";
                })
              }
              return newmessage;
          }
          messagelooping(message).then(
            (value)=>{
              message=value.slice(0,-2);
              res.send(message);
            }
            
          );
          
          
        }
        sendingmessage(message);
      })
      .catch((error) => {
        console.log(error)
        res.set('Content-Type', 'text/plain');
        res.status(404).send("Event Not Found!")
      })    
      ;

    
  });
  //P5.Q2
  app.get('/lo/:locID',(req,res)=>{
    // Search for locID
    let locID = req.params.locID;
    
    console.log("locID="+locID);
    // let pizza = {name:"spiderman",ing:"ham",base:"bread"};
     
    DataFound = Location.findOne({ locID: { $eq: locID } })
      .then((data) => {
        if (data==null) 
          throw 404;

          res.set('Content-Type', 'text/plain');
          // res.send(data);
          res.send("{\n\"locID\": "+ data.locID + ",\n" +
          "\"name\": \"" + data.name + "\",\n" +
          "\"quota\": " + data.quota + "\n" +
          "}" + "\n"
          );
      })
      .catch((error) => {
        console.log(error)

        res.set('Content-Type', 'text/plain');
        res.status(404).send("Location Not Found!")
      });
  });
  //P5.Q3
  app.get('/lo',(req,res)=>{
    console.log("/lo detected");   
    res.set('Content-Type', 'text/plain');
    let message = "All Location Found!\n[\n";
    
    Location.find({})
      .then((data) => {
        if (data==null) {throw 404;}
        sendingmessage = (message) =>  {
          async function messagelooping(newmessage){
              for(let curLoc of data){
                  newmessage+="{\n\"eventID\": "+ curLoc.locID + ",\n" +
                  "\"name\": \"" + curLoc.name + "\",\n" +
                  "\"quota\": " + curLoc.quota + "\n" +
                  "}\n,\n";
              }
              return newmessage;
          }
          messagelooping(message).then(
            (value)=>{
              message=value.slice(0,-2);
              res.send(message);
            }
          );
        }
        sendingmessage(message);
      })
      .catch((error) => {
        console.log(error)
        res.set('Content-Type', 'text/plain');
        res.status(404).send("Event Not Found!")
      })    
      ;
  });
  //P6
  app.put('/ev/:eventID',(req,res)=>{
    let eventID= req.params.eventID;
    let name= req.body.name;
    let quota= req.body.quota;
    let locID= req.body.locID;
  // find eventID if locID is found
  Location.findOne({locID:{ $eq : locID}})
    .then((locdata)=>{
      // update the detail if eventID is found
      console.log(locdata);
      Event.findOneAndUpdate(
        { eventID: { $eq:eventID } },  
        { 
          _location:locdata._id,
          name:name,
          quota:quota
        }, 
        { new: true},  
      )
      .then((data) => {
        console.log('the updated data is:'+ data);
        res.set('Content-Type', 'text/plain');
        res.send('the updated data is:'+ data);
      })
      .catch((error) => console.log(error));
    })


  })
  

   // handle ALL requests
  app.all('/*', (req, res) => {
    // send this to client
    res.send('Hello World!');
  });

})




// listen to port 3000
const server = app.listen(3000);


