import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom'

// Sample Data
const events = [
  { // Venue 1 Event 1
    eventId: 155812,
    title: '"2001: A Space Odyssey" (4K Restored Version) - !magine Fest',
    date: '2023-12-10',
    price: 60,
    presenter: 'Leisure and Cultural Services Department',
    description: "As Strauss’s symphonic poem Also sprach Zarathustra opens the film, apes are seen living a raw life in the prehistoric times. Suddenly a monolith appears, triggering us to ask, if this is ground zero of humankind evolution? Fast-forwarding to the era of space travelling, a spacecraft is seen propelling into the vast universe, embarking on an exploration accompanied by The Blue Danube. The mysterious monolith then reappears on the Moon, sending signals to Jupiter. To unlock the mystery, the five-men crew switches gears and heads to Jupiter, however, as the supercomputer HAL 9000 pilots the ship, a malfunction brings the astronauts into an unprecedented crisis. For this epochal sci-fi masterpiece of immense imagination, Kubrick worked with sci-fi novelist Arthur C. Clarke to create a voyage beginning with our prehistoric ape-ancestry past, and leaping into the future with the birth of the Starchild — an ultimate reflection on human evolution and existence. Then through an episode of computer mutiny to interrogate the encroaching dominance and threat of technologies towards mankind. The vision of the story is profoundly magnificent. The film was produced when computer-generated imagery (CGI) did not exist, nevertheless, the visuals were stunningly outstanding back then, and are still breathtaking as of today. Post-screening talk in Cantonese Speaker: Dr Derek Lam │ Host: Ernest Chan",
    venueId: 75010017,
    venue: 'Hong Kong Film Archive (Cinema)',
    longitude: 114.222075,
    latitude: 22.285056,
    URL:'https://www.filmarchive.gov.hk/en/web/hkfa/home.html'
  },
  { // Venue 1 Event 2
    eventId: 155838,
    title: '"AMatter of Life and Death" (4K Restored Version) - !magineFest',
    date: '2024-01-06',
    price: 60,
    presenter: 'Leisure and Cultural Services Department',
    description: "Squadron Leader Peter is trapped in a blazing bomber without a parachute. Preparing to die, he calls over radio and operator June picks up, listening to his last words — but the farewell is a bit too soon. Peter miraculously survives the jump out of the plane as the guiding angel misses him in the thick fog. Peter meets June and they fall in love, but his worsening concussion needs a surgery to cure. The heaven seizes the opportunity and tries to bring him to the other world whilst he undergoes the dangerous operation. Peter must now appeal before god for the love of his life and fight to stay alive on Earth.This imaginative fantastical classic by Powell and Pressburger has a witty and humorous take on life and death. The interesting comparison between the colourful Earth and the black and white heaven even gets the angel to remark: “One is starved for Technicolor up there.” The grand staircase leading up to heaven is decorated as a hall of fame; and the trial Peter goes through is a typical court drama, one that requires a defense attorney and a testimony to prove his true love. Regarding facing death, this film can be cross-referenced with >After Life. Post-screening talk in Cantonese by Horace Chan Speaker: Horace Chan",
    venueId: 75010017,
    venue: 'Hong Kong Film Archive (Cinema)',
    longitude: 114.222075,
    latitude: 22.285056,
    URL:'https://www.filmarchive.gov.hk/en/web/hkfa/home.html'
  },
  { // Venue 1 Event 3
    eventId: 154984,
    title: '"Elaha" - German Film Forum: Generation Z',
    date: '2024-03-15',
    price: 60,
    presenter: 'Goethe-Institut Hongkong',
    description: "A naked young woman is standing in front of a running washing machine. Flashback. 22-year-old Elaha tries all that she can to recover a supposed “innocence” that she has lost through sex. A plastic surgeon is set to help her. But she cannot come up with the money for the costly procedure. While looking for an alternative, she comes across a special product – a capsule of artificial blood. But what at first seems to be a solution to her problem ultimately forces her into self-exploitation.",
    venueId: 75010017,
    venue: 'Hong Kong Film Archive (Cinema)',
    longitude: 114.222075,
    latitude: 22.285056,
    URL:'https://www.filmarchive.gov.hk/en/web/hkfa/home.html'
  },
  { // Venue 2 Event 1
    eventId: 155614,
    title: '"ADifficult Year"- The 52nd Hong Kong French Film Festival',
    date: '2023-12-06',
    price: 68,
    presenter: 'Alliance Française de Hong Kong',
    description: "Albert and Bruno are compulsive consumers, over-indebted, they live between small schemes for one and a personal life adrift for the other. It’s in the community work they’re both doing to pull themselves up by their bootstraps that they come across a group of young activists who are revolted by climate change, social justice and eco-responsibility… ",
    venueId: 87510010,
    venue: 'Hong Kong City Hall (Theatre)',
    longitude: 114.161545,
    latitude: 22.282279,
    URL:'https://www.lcsd.gov.hk/hkch' 
  },
  { // Venue 2 Event 2
    eventId: 155626,
    title: '"AbbéPierre - A Century of Devotion"- The 52nd Hong Kong French Film Festival',
    date: '2023-12-10',
    price: 68,
    presenter: 'Alliance Française de Hong Kong',
    description: "Born and raised a catholic, Henri Grouès is determined to become a priest. WWII begins and decides otherwise: he joins the Resistance. Losing a friend on the battlefield, facing the horrors of war, Henri Grouès emerges as a new man: L’Abbé Pierre. L’Abbé Pierre will fight for the homeless and give a voice to the speechless. A humanist, he met everyone in needs. His dedication earned him the respect of his peers and a place in every hearts. His impact earned him a place in History. ",
    venueId: 87510010,
    venue: 'Hong Kong City Hall (Theatre)',
    longitude: 114.161545,
    latitude: 22.282279,
    URL:'https://www.lcsd.gov.hk/hkch' 
  },
  { // Venue 2 Event 3
    eventId: 155622,
    title: "'Don't Look Now: We're Being Shot At'- The 52nd Hong Kong French Film Festival",
    date: '2023-12-09',
    price: 68,
    presenter: 'Alliance Française de Hong Kong',
    description: "Summer 1941. Over Nazi-occupied France, a Royal Air Force B17 Flying Fortress becomes lost after a mission and is shot down over Paris by German flak. The crew parachutes out over the city, where they run into and are hidden by a house painter and the grumbling conductor of the Opéra National de Paris. Involuntarily, they get themselves tangled up in the manhunt against the aviators as they help the airmen to escape to the free zone with the help of Resistance fighters and sympathisers. ",
    venueId: 87510010,
    venue: 'Hong Kong City Hall (Theatre)',
    longitude: 114.161545,
    latitude: 22.282279,
    URL:'https://www.lcsd.gov.hk/hkch' 
  },
  { // Venue 3 Event 1
    eventId: 154999,
    title: "35th Kowloon City District Joint School Concert",
    date: "2023-12-17",
    price: 0,
    presenter: "Kowloon City District Children's Chorus",
    description: null,
    venueId: 87610118,
    venue: "Ko Shan Theatre (Theatre)",
    longitude: 114.18556,
    latitude: 22.31368,
    URL:'https://www.lcsd.gov.hk/en/kst/'
  },
  { // Venue 3 Event 2
    eventId: 155828,
    title: "Cantonese Opera Excerpts",
    date: "2024-01-01",
    price: 0,
    presenter: "Ngok Tou Tou Chinese Musical Club",
    description: null,
    venueId: 87610118,
    venue: "Ko Shan Theatre (Theatre)",
    longitude: 114.18556,
    latitude: 22.31368,
    URL:'https://www.lcsd.gov.hk/en/kst/'
  },
  { // Venue 3 Event 3
    eventId: 155005,
    title: "Cantonese Opera Excerpts",
    date: "2023-12-18",
    price: 0,
    presenter: "Xi Qu House",
    description: null,
    venueId: 87610118,
    venue: "Ko Shan Theatre (Theatre)",
    longitude: 114.18556,
    latitude: 22.31368,
    URL:'https://www.lcsd.gov.hk/en/kst/'
  },
  { // Venue 4 Event 1
    eventId: 154955,
    title: "Annual Dancing Variety Show of STAA",
    date: "2023-12-30",
    price: 80,
    presenter: "Sha Tin Arts Association",
    description: null,
    venueId: 36310035,
    venue: "Sha Tin Town Hall (Auditorium)",
    longitude: 114.18990 ,
    latitude: 22.38136,
    URL:'https://www.lcsd.gov.hk/en/stth/'
  },
  { // Venue 4 Event 2
    eventId: 154956,
    title: "Sha Tin Choir Annual Concert 2023",
    date: "2023-12-30",
    price: 80,
    presenter: "Sha Tin Arts Association",
    description: null,
    venueId: 36310035,
    venue: "Sha Tin Town Hall (Auditorium)",
    longitude: 114.18990 ,
    latitude: 22.38136,
    URL:'https://www.lcsd.gov.hk/en/stth/'
  },
  { // Venue 4 Event 3
    eventId: 154952,
    title: "Supernova Singers Singing Contest 2023",
    date: "2023-12-16",
    price: 100,
    presenter: "Sha Tin Arts Association",
    description: null,
    venueId: 36310035,
    venue: "Sha Tin Town Hall (Auditorium)",
    longitude: 114.18990 ,
    latitude: 22.38136,
    URL:'https://www.lcsd.gov.hk/en/stth/'
  },
  { // Venue 5 Event 1
    eventId: 155692,
    title: "Oldies Concert",
    date: "2023-12-05",
    price: 0,
    presenter: "Yip Yip Music Group",
    description: null,
    venueId: 76810049,
    venue: "Tuen Mun Town Hall (Cultural Activities Hall)",
    longitude: 113.976771 ,
    latitude: 22.391810,
    URL:'https://www.lcsd.gov.hk/en/tmth/'
  },
  { // Venue 5 Event 2
    eventId: 155695,
    title: "Variety Show",
    date: "2023-12-08",
    price: 0,
    presenter: "The Collections",
    description: null,
    venueId: 76810049,
    venue: "Tuen Mun Town Hall (Cultural Activities Hall)",
    longitude: 113.976771 ,
    latitude: 22.391810,
    URL:'https://www.lcsd.gov.hk/en/tmth/'
  },
  { // Venue 5 Event 3
    eventId: 155692,
    title: "Oldies Concert",
    date: "2023-12-05",
    price: 0,
    presenter: "Tuen Mun Friends Singing Association",
    description: null,
    venueId: 76810049,
    venue: "Tuen Mun Town Hall (Cultural Activities Hall)",
    longitude: 113.976771 ,
    latitude: 22.391810,
    URL:'https://www.lcsd.gov.hk/en/tmth/'
  },
  { // Venue 6 Event 1
    eventId: 155708,
    title: "Drama Society, City University of Hong Kong Student's Union, Freshmen Performance 2023",
    date: "2023-12-19",
    price: 100,
    presenter: "Drama Society, City University of Hong Kong Student's Union ",
    description: null,
    venueId: 87310051,
    venue: "Yuen Long Theatre (Auditorium) ",
    longitude: 114.02289 ,
    latitude: 22.44152,
    URL:'https://www.lcsd.gov.hk/en/ylt/'
  },
  { // Venue 6 Event 2
    eventId: 155707,
    title: "Hong Kong Vigor Marching Band Annual Concert 2023",
    date: "2023-12-16",
    price: 150,
    presenter: "Hong Kong Vigor Marching Band",
    description: null,
    venueId: 87310051,
    venue: "Yuen Long Theatre (Auditorium) ",
    longitude: 114.02289 ,
    latitude: 22.44152,
    URL:'https://www.lcsd.gov.hk/en/ylt/'
  },
  { // Venue 6 Event 3
    eventId: 155704,
    title: "Oldies Concert",
    date: "2023-12-06",
    price: 0,
    presenter: "Hon Joy Vocal Music Cultural Association",
    description: null,
    venueId: 87310051,
    venue: "Yuen Long Theatre (Auditorium) ",
    longitude: 114.02289 ,
    latitude: 22.44152,
    URL:'https://www.lcsd.gov.hk/en/ylt/' 
  },
  { // Venue 7 Event 1
    eventId: 154153,
    title: "HKECO Annual Concert",
    date: "2024-01-01",
    price: 160,
    presenter: "Hong Kong Elite Chamber Orchestra",
    description: null,
    venueId: 87410030,
    venue: "Ngau Chi Wan Civic Centre (Theatre)",
    longitude: 114.208766 ,
    latitude: 22.334583,
    URL:'https://www.lcsd.gov.hk/en/ncwcc/'
  },
  { // Venue 7 Event 2
    eventId: 155768,
    title: "Ngau Chi Wan Civic Centre Venue Partnership Scheme - 'Converging Beams' by E-Side Dance Company",
    date: "2024-01-01",
    price: 160,
    presenter: "Hong Kong Elite Chamber Orchestra",
    description: null,
    venueId: 87410030,
    venue: "Ngau Chi Wan Civic Centre (Theatre)",
    longitude: 114.208766 ,
    latitude: 22.334583,
    URL:'https://www.lcsd.gov.hk/en/ncwcc/'
  },
  { // Venue 7 Event 3
    eventId: 154153,
    title: "Variety Show",
    date: "2024-01-30",
    price: 0,
    presenter: "Sarah Singing Concert",
    description: null,
    venueId: 87410030,
    venue: "Ngau Chi Wan Civic Centre (Theatre)",
    longitude: 114.208766 ,
    latitude: 22.334583,
    URL:'https://www.lcsd.gov.hk/en/ncwcc/'
  },
  { // Venue 8 Event 1
    eventId: 152232,
    title: "Golden Oldies Concert II",
    date: "2023-12-12",
    price: 0,
    presenter: "Jin Yuan Xun Artists Association",
    description: null,
    venueId: 87810042,
    venue: "Sheung Wan Civic Centre (Theatre)",
    longitude: 114.14967 ,
    latitude: 22.28602,
    URL:'https://www.lcsd.gov.hk/en/swcc/'
  },
  { // Venue 8 Event 2
    eventId: 152235,
    title: "Singing Concert",
    date: "2023-12-14",
    price: 0,
    presenter: "Happy Together Fans Club",
    description: null,
    venueId: 87810042,
    venue: "Sheung Wan Civic Centre (Theatre)",
    longitude: 114.14967 ,
    latitude: 22.28602,
    URL:'https://www.lcsd.gov.hk/en/swcc/'
  },
  { // Venue 8 Event 3
    eventId: 153063,
    title: "Sheung Wan Civic Centre Venue Partnership Scheme - iStage: Drama",
    date: "2023-12-23",
    price: 280,
    presenter: "iStage",
    description: null,
    venueId: 87810042,
    venue: "Sheung Wan Civic Centre (Theatre)",
    longitude: 114.14967 ,
    latitude: 22.28602,
    URL:'https://www.lcsd.gov.hk/en/swcc/'
  },
  { // Venue 9 Event 1
    eventId: 154945,
    title: "Cantonese Music Sings Awareness",
    date: "2023-12-31",
    price: 0,
    presenter: "Happy Singing Together Chinese Opera Association",
    description: null,
    venueId: 3110031,
    venue: "North District Town Hall (Auditorium)",
    longitude: 114.128911 ,
    latitude: 22.501639,
    URL:'https://www.lcsd.gov.hk/en/ndth/'
  },
  { // Venue 9 Event 2
    eventId: 154943,
    title: "Cantonese Operatic Songs Concert",
    date: "2023-12-29",
    price: 0,
    presenter: "Angel Song Association",
    description: null,
    venueId: 3110031,
    venue: "North District Town Hall (Auditorium)",
    longitude: 114.128911 ,
    latitude: 22.501639,
    URL:'https://www.lcsd.gov.hk/en/ndth/'
  },
  { // Venue 9 Event 3
    eventId: 154939,
    title: "Cantonese Operatic Songs Concert",
    date: "2023-12-03",
    price: 0,
    presenter: "Analog Music Association",
    description: null,
    venueId: 3110031,
    venue: "North District Town Hall (Auditorium)",
    longitude: 114.128911 ,
    latitude: 22.501639,
    URL:'https://www.lcsd.gov.hk/en/ndth/' 
  },
  { // Venue 10 Event 1
    eventId: 155638,
    title: "2023 KidsArt Drawing Competition Exhibition",
    date: "2023-12-22",
    price: 0,
    presenter: "China Life Insurance (Overseas)",
    description: null,
    venueId: 155638,
    venue: "Hong Kong Cultural Centre (Exhibition Gallery)",
    longitude: 114.17053 ,
    latitude: 22.29386,
    URL:'https://www.hkculturalcentre.gov.hk/'
  },
  { // Venue 10 Event 2 
    eventId: 155639,
    title: "Animitta Itinerant Exhibition",
    date: "2023-12-25",
    price: 0,
    presenter: "Hong Kong Arts & Craft Association",
    description: null,
    venueId: 155638,
    venue: "Hong Kong Cultural Centre (Exhibition Gallery)",
    longitude: 114.17053 ,
    latitude: 22.29386,
    URL:'https://www.hkculturalcentre.gov.hk/'
  },
  { // Venue 10 Event 3
    eventId: 155636,
    title: "Art Point Studio 10th Anniversary Art Exhibition",
    date: "2023-12-08",
    price: 0,
    presenter: "Art Point Studio",
    description: null,
    venueId: 155638,
    venue: "Hong Kong Cultural Centre (Exhibition Gallery)",
    longitude: 114.17053 ,
    latitude: 22.29386,
    URL:'https://www.hkculturalcentre.gov.hk/'  
  },
];

// User Action 1
const LocationTable = ({ events }) => {
  const [locations, setLocations] = useState([]);

  useEffect(() => {
    // Logic to group events by venue and count the number of events at each venue
    const venueMap = new Map();

    events.forEach(event => {
      const { venueId, venue, URL } = event;
      if (venueMap.has(venueId)) {
        venueMap.get(venueId).count++;
      } else {
        venueMap.set(venueId, { venue, count: 1, URL }); // Include URL in the map
      }
    });

    const sortedLocations = Array.from(venueMap.values()).sort((a, b) => b.count - a.count);
    setLocations(sortedLocations);
  }, [events]);

  return (
    <div>
      <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Locations Table</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th style={{ padding: '8px', border: '1px solid #000' }}>Location</th>
            <th style={{ padding: '8px', border: '1px solid #000' }}>Number of Events</th>
          </tr>
        </thead>
        <tbody>
          {locations.map(location => (
            <tr key={location.venueId}>
              <td style={{ padding: '8px', border: '1px solid #000' }}>
                <a
                  href={location.URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  style={{ textDecoration: 'underline', color: 'blue' }}
                >
                  {location.venue}
                </a>
              </td>
              <td style={{ padding: '8px', border: '1px solid #000' }}>{location.count}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

/* Comments for User Action 1:
After testing, the sorting works well.
Feel free to add / delete existing data to test it.
Just to remember change it back after testing.
*/

// User Action 2
const MapComponent = ({ locations }) => {
  useEffect(() => {
    // Initialize map
    const map = new window.google.maps.Map(document.getElementById('map'), {
      center: { lat: 22.344044, lng: 114.100998 },
      zoom: 11,
    });

    // Add markers for each location
    locations.forEach(location => {
      const marker = new window.google.maps.Marker({
        position: { lat: location.latitude, lng: location.longitude },
        map,
        title: location.venue,
      });

      // Add a click event to each marker
      marker.addListener('click', () => {
        // Redirect to the location link when a marker is clicked
        window.location.href = location.URL;
      });
    });
  }, [locations]);

  return <div id="map" style={{ height: '400px' }} />;
};

// User Action 3
const LocationSearch = ({ locations }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);

  const handleSearch = () => {
    const filteredLocations = locations.filter(
      (location, index, self) =>
        index === self.findIndex(l => l.venue.toLowerCase() === location.venue.toLowerCase())
    ).filter(location =>
      location.venue.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setSearchResults(filteredLocations);
  };

  const handleChange = e => {
    setSearchResults([]);             // Clear Search Results
    setSearchTerm(e.target.value);
  };

  return (
    <div style={{ fontFamily: 'Arial, sans-serif' }}>
      <h2 style={{ textAlign: 'center', marginBottom: '20px' }}>Location Search</h2>
      <div style={{ textAlign: 'center', marginBottom: '20px' }}>
        <input
          type="text"
          placeholder="Search by location name..."
          value={searchTerm}
          onChange={handleChange}
          style={{ padding: '8px', marginRight: '10px' }}
        />
        <button onClick={handleSearch} style={{ padding: '8px 12px' }}>Search</button>
      </div>

      <h3 style={{ textAlign: 'center', marginBottom: '10px' }}>Results</h3>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr style={{ backgroundColor: '#f2f2f2' }}>
            <th style={{ padding: '8px', border: '1px solid #ddd' }}>Location</th>
            <th style={{ padding: '8px', border: '1px solid #ddd' }}>Latitude</th>
            <th style={{ padding: '8px', border: '1px solid #ddd' }}>Longitude</th>
          </tr>
        </thead>
        <tbody>
          {searchResults.map(location => (
            <tr key={location.venueId} style={{ border: '1px solid #ddd' }}>
              <td style={{ padding: '8px', border: '1px solid #ddd' }}>{location.venue}</td>
              <td style={{ padding: '8px', border: '1px solid #ddd' }}>{location.latitude}</td>
              <td style={{ padding: '8px', border: '1px solid #ddd' }}>{location.longitude}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

const App = () => {
  return (
    <div>
      {/* Pass the 'events' array to both components */}
        <LocationSearch locations={events} /> <br></br><br></br><br></br>
        <LocationTable events={events} /> <br></br><br></br><br></br>
        <MapComponent locations={events}></MapComponent>
    </div>
  );
};

const root = ReactDOM.createRoot(document.querySelector("#app"));
root.render(<App />);